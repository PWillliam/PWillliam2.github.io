<?php 
$bdd = new PDO('mysql:host=localhost;dbname=crud;charset=utf8;', 'will', 'Sepp666');